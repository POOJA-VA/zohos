package com.example.zoho

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
