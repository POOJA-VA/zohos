import 'app_localizations.dart';

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get login => 'Connexion';

  @override
  String get register => 'S\'inscrire';

  @override
  String get accountNeed => 'Vous n\'avez pas de compte ?';

  @override
  String get alreadyHaveAccount => 'Vous avez déjà un compte ?';

  @override
  String get home => 'Maison';

  @override
  String get report => 'Rapport';

  @override
  String get summaryReport => 'Rapport récapitulatif';

  @override
  String get totalTime => 'Temps total';

  @override
  String get averageTime => 'Durée moyenne';

  @override
  String get approvals => 'Agréations';

  @override
  String get pending => 'En attente';

  @override
  String get approved => 'Approuvé';

  @override
  String get rejected => 'Rejeté';

  @override
  String get location => 'Emplacement';

  @override
  String get welcomeAdmin => 'Bienvenue administrateur';
}
