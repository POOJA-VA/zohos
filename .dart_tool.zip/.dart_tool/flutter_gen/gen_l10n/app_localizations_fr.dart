import 'app_localizations.dart';

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get login => 'Einloggen';

  @override
  String get register => 'Registrieren';

  @override
  String get accountNeed => 'Sie haben kein Konto?';

  @override
  String get alreadyHaveAccount => 'Haben Sie bereits ein Konto?';

  @override
  String get home => 'Zuhause';

  @override
  String get report => 'Bericht';

  @override
  String get summaryReport => 'Zusammenfassungsbericht';

  @override
  String get totalTime => 'Gesamtzeit';

  @override
  String get averageTime => 'Durchschnittliche Zeit';

  @override
  String get approvals => 'Genehmigungen';

  @override
  String get pending => 'Ausstehend';

  @override
  String get approved => 'Genehmigt';

  @override
  String get rejected => 'Abgelehnt';

  @override
  String get location => 'Standort';

  @override
  String get welcomeAdmin => 'Willkommen Admin';
}
