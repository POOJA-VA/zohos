import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get login => 'Login';

  @override
  String get register => 'Register';

  @override
  String get accountNeed => 'Don\'t have an account?';

  @override
  String get alreadyHaveAccount => 'Already have an account?';

  @override
  String get home => 'Home';

  @override
  String get report => 'Report';

  @override
  String get summaryReport => 'Summary Report';

  @override
  String get totalTime => 'Total Time';

  @override
  String get averageTime => 'Average Time';

  @override
  String get approvals => 'Approvals';

  @override
  String get pending => 'Pending';

  @override
  String get approved => 'Approved';

  @override
  String get rejected => 'Rejected';

  @override
  String get location => 'Location';

  @override
  String get welcomeAdmin => 'Welcome Admin';
}
